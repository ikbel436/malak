<?php

class reservation
{

    private $id;
    private $date;
    private $nbrPlace;
    private $etat;
    private $idVoyage;
    private $idUser;
    function __construct($date,$nbrPlace,$etat,$idVoyage)
    {
       // $this->id=$id;
        $this->date=$date;
        $this->nbrPlace=$nbrPlace;
        $this->etat=$etat;
        $this->idVoyage=$idVoyage;
        $this->idUser=1;
    }
    function getidUser()
    {
        return $this->idUser;

    }
    function setidUser($id)
    {
        $this->idUser=$id;

    }
    function getdate()
    {
        return $this->date;

    }
    function setdate($date)
    {
        $this->date=$date;

    }
    function getnbrPlace()
    {
        return $this->nbrPlace;
    }
    function setnbrPlace($nbrPlace)
    {
        $this->nbrPlace=$nbrPlace;

    }
    function getetat()
    {
        return $this->etat;
    }
    function  setetat($etat)
    {
        $this->etat=$etat;

    }

    function  getidVoyage()
    {
        return $this->idVoyage;
    }
    function setidVoyage($idVaoyage)
    {$this->idVoyage=$idVoyage;
    }


}
?>