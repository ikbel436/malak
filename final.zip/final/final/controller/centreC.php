<?PHP
require_once "config.php";


class centreC
{
    function ajouterCentre($centre)
    {
        $sql = "insert into centre (id,nom,adresse,email,tel,dateAjout,dateModif,etat) values (:id,:nom, :adresse, :email, :tel, :dateAjout, :dateModif, :etat)";
        $db = config::getConnexion();
        try {
            $req = $db->prepare($sql);

            $req->bindValue(':id', $centre->getid());
            $req->bindValue(':nom', $centre->getnom());
            $req->bindValue(':adresse', $centre->getadresse());
            $req->bindValue(':email', $centre->getemail());
            $req->bindValue(':tel', $centre->gettel());
            $req->bindValue(':dateAjout', $centre->getdateAjout());
            $req->bindValue(':dateModif', $centre->getdateModif());
            $req->bindValue(':etat', $centre->getetat());


            $req->execute();

        } catch (Exception $e) {
            echo 'Erreur: ' . $e->getMessage();
        }
    }

    function afficher()
    {
        $sql = "SELECT * from centre";
        $db = config::getConnexion();
        try {
            $liste = $db->query($sql);
            return $liste;
        } catch (Exception $e) {
            die('Erreur: ' .$e->getMessage());
        }
    }


    function supprimer($id)
    {
        $sql = "DELETE FROM centre WHERE id= :id";
        $db = config::getConnexion();
        $req = $db->prepare($sql);
        $req->bindValue(':id', $id);
        try {
            $req->execute();
        } catch (Exception $e) {
            die('Erreur: ' .$e->getMessage());
        }
    }
    function recuperer($id){
        $sql="SELECT * from centre where id=$id";
        $db = config::getConnexion();
        try{
            $liste=$db->query($sql);
            return $liste;
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }




    function modifier($centre, $id)
    {
        try {
            $db = config::getConnexion();
            $query = $db->prepare(
                'UPDATE centre SET 
						nom = :nom, 
						adresse = :adresse,
						email = :email,
						tel = :tel,
						dateAjout=:dateAjout,
						dateModif = :dateModif,
						etat = :etat
					WHERE id = :id'
            );

            $query->execute([
                'nom'=>$centre->getnom(),
                'adresse'=>$centre->getadresse(),
                'email'=>$centre->getemail(),
                'tel'=>$centre->gettel(),
                'dateAjout'=>$centre->getdateAjout(),
                'dateModif'=>$centre->getdateModif(),
                'etat'=>$centre->getetat(),
                'id'=>$id
            ]);
            echo $query->rowCount() . " records UPDATED successfully <br>";
        } catch (PDOException $e) {
            $e->getMessage();
        }
    }


}
?>