<?PHP
require_once "config.php";


class besoinsC
{
    function ajouterb($besoins)
    {
        $sql = "insert into besoins (id,nom,description) values (:id,:nom,:description)";
        $db = config::getConnexion();
        try {
            $req = $db->prepare($sql);

            $req->bindValue(':id', $besoins->getid());
            $req->bindValue(':nom', $besoins->getnom());

            $req->bindValue(':description', $besoins->getdescription());


            $req->execute();

        } catch (Exception $e) {
            echo 'Erreur: ' . $e->getMessage();
        }
    }

    function afficherb()
    {
        $sql = "SELECT * from besoins";
        $db = config::getConnexion();
        try {
            $liste = $db->query($sql);
            return $liste;
        } catch (Exception $e) {
            die('Erreur: ' .$e->getMessage());
        }
    }


    function supprimerb($id)
    {
        $sql = "DELETE FROM besoins WHERE id= :id";
        $db = config::getConnexion();
        $req = $db->prepare($sql);
        $req->bindValue(':id', $id);
        try {
            $req->execute();
        } catch (Exception $e) {
            die('Erreur: ' .$e->getMessage());
        }
    }
    function recupererb($id){
        $sql="SELECT * from besoins where id=$id";
        $db = config::getConnexion();
        try{
            $liste=$db->query($sql);
            return $liste;
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }




    function modifierb($besoins, $id)
    {
        try {
            $db = config::getConnexion();
            $query = $db->prepare(
                'UPDATE besoins SET 
                       
						nom = :nom, 
						description = :description,
						
					
					WHERE id = :id'
            );

            $query->execute([
                'nom'=>$besoins->getnom(),
                'description'=>$besoins->getdescription(),
                // 'idbesoin'=>$association->getidbesoin(),
                'id'=>$id
            ]);
            echo $query->rowCount() . " records UPDATED successfully <br>";
        } catch (PDOException $e) {
            $e->getMessage();
        }
    }

}
?>

