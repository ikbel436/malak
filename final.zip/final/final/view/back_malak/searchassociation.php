<?php
require_once '../../controller/besoinC.php';
$besoinC=new besoinsC();
$besoin= $besoin->afficherb();
if(isset($_POST['idbesoin'])&&isset($_POST['search']))
{
    $list=$besoinC->afficherassociation($_POST['idbesoin'])
}
?>